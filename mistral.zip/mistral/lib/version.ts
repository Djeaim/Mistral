export const VERSION = process.env.GIT_SHA || 'dev';


